package com.icia.musicproject.repository;

public interface BoardRepository {
}
