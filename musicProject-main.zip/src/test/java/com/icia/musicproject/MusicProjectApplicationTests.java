package com.icia.musicproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
